#ident %W% %E% %Q%
###########################################################################
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
###########################################################################
SRCROOT=	..
RULESDIR=	RULES
include		$(SRCROOT)/$(RULESDIR)/rules.top
###########################################################################

MANDIR=		man
TARGETMAN=	apple_driver
MANSECT=	$(MANSECT_ADMIN)
MANSUFFIX=	$(MANSUFF_ADMIN)
MANFILE=	apple_driver.8

###########################################################################
include		$(SRCROOT)/$(RULESDIR)/rules.man
###########################################################################
